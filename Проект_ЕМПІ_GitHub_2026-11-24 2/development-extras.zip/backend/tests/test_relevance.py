import pytest
from conftest import get, send
from sqlalchemy import select
from test_workflow import REFERENCE, process, question, submit

from app.database.session import session
from app.models import AnalysisResult, Submission, SubmissionStatus
from app.nlp.analyzer import Candidate, analyze
from app.nlp.methodology import RELEVANCE_POLICY
from app.nlp.provider import TestProvider as FixtureProvider
from app.schemas.analysis import AnalysisSettings
from app.schemas.catalog import ConceptIn, ConflictRule
from scripts.reanalyze_unreviewed import enqueue_unreviewed


def score(answer, reference, semantic, concepts=None, rules=None, config=None):
    candidate = Candidate(1, reference, reference, concepts or [], rules or [])
    return analyze(FixtureProvider(), answer, [candidate], [semantic], config or AnalysisSettings())


@pytest.mark.parametrize('answer', [
    'Користувач вводить відповідь',
    'Користувач вводить відповідь ' * 25,
    'Я не знаю відповіді на це запитання',
    'Система користувач інформація дані',
])
def test_unrelated_answers_are_exactly_zero_even_when_raw_cosine_is_positive(answer):
    result = score(answer, 'REST API описує ресурси та уніфікований інтерфейс', .24)
    assert result.raw_similarity > 0
    assert result.final_similarity == 0
    assert result.category.value == 'LOW_MATCH'
    assert result.relevance['passed'] is False


def test_generic_overlap_is_not_evidence_of_subject_knowledge():
    result = score('користувач система дані', 'користувач система дані ресурси інтерфейс', .65)
    assert result.lexical_similarity > 0
    assert result.relevance['shared_terms'] == []
    assert result.relevance['reason'] == 'no_content_evidence'
    assert result.final_similarity == 0


def test_correct_paraphrase_can_use_semantics_without_exact_keywords():
    result = score('сховище впорядковує відомості', 'база організує інформацію', .91)
    assert result.lexical_similarity == 0
    assert result.relevance['passed'] is True
    assert result.final_similarity > 0


def test_explicit_synonyms_and_meaningful_partial_answers_keep_credit():
    result = score('сховище впорядковує відомості', 'база організує інформацію', .70,
                   [ConceptIn(concept='інформацію', synonyms=['відомості'])])
    assert result.concept_coverage == 1
    assert result.relevance['passed'] is True
    assert 0 < result.final_similarity < 1
    partial = score('м’ютекс захоплює блокування', 'м’ютекс захоплює блокування та звільняє потік', .34)
    assert partial.relevance['passed'] is True
    assert partial.final_similarity > 0


def test_keyword_stuffing_with_low_semantic_relevance_gets_no_credit():
    result = score('ресурси ресурси квіти город рослини', 'ресурси пам’ять процесор', .20,
                   [ConceptIn(concept='ресурси')])
    assert result.concept_coverage == 1
    assert result.raw_similarity > 0
    assert result.final_similarity == 0


def test_critical_contradiction_is_zero_despite_exact_text_and_high_similarity():
    text = 'сервер завжди зберігає стан'
    result = score(text, text, 1, rules=[ConflictRule(phrase=text, message='Порушено stateless.')])
    assert result.raw_similarity == 1
    assert result.final_similarity == 0
    assert result.relevance['reason'] == 'critical_conflict'


def test_all_reference_gates_are_applied_before_maximum_and_never_sum_scores():
    candidates = [Candidate(i, text, text, [], []) for i, text in enumerate([
        'ресурси сервер передає запити', 'інтерфейс отримує HTTP запити',
    ], 1)]
    result = analyze(FixtureProvider(), 'Користувач вводить відповідь', candidates, [.40, .50], AnalysisSettings())
    assert all(row['raw_similarity'] > 0 and row['final_similarity'] == 0 for row in result.comparisons)
    assert result.final_similarity == 0
    assert sum(row['selected'] for row in result.comparisons) == 1
    answer = 'інтерфейс отримує HTTP запити'
    result = analyze(FixtureProvider(), answer, candidates, [.55, 1.0], AnalysisSettings())
    assert result.candidate.reference_id == 2
    assert result.final_similarity == 1


def test_zero_stays_low_match_even_if_category_thresholds_are_lowered():
    result = score('город квіти', 'операційна система', .15,
                   config=AnalysisSettings(low_threshold=0, high_threshold=.1))
    assert result.final_similarity == 0
    assert result.category.value == 'LOW_MATCH'


@pytest.mark.postgres
def test_worker_persists_raw_score_zero_gate_and_reasons_for_every_reference(clients, school):
    item = question(clients['teacher'], school['id'])
    record = submit(clients['student'], item['id'], 'Садівник вирощує квіти на городі.')
    process()
    analysis = get(clients['teacher'], f"/submissions/{record['id']}/result")['analysis']
    assert analysis['final_similarity'] == 0
    assert analysis['configuration_snapshot']['algorithm_version'] == '3.0.0'
    assert analysis['configuration_snapshot']['relevance_policy'] == RELEVANCE_POLICY
    assert analysis['material_snapshot']['scoring']['relevance']['passed'] is False
    assert all(not row['relevance']['passed'] and row['final_similarity'] == 0
               for row in analysis['material_snapshot']['comparisons'])
    visible = get(clients['student'], f"/submissions/{record['id']}/result")['analysis']
    assert visible['final_similarity'] == 0 and '0%' in visible['explanation']


@pytest.mark.postgres
def test_upgrade_queues_only_outdated_unreviewed_answers_and_keeps_history(clients, school):
    teacher, student = clients['teacher'], clients['student']
    item = question(teacher, school['id'])
    records = []
    for _ in range(3):
        record = submit(student, item['id'], REFERENCE)
        process()
        analysis = get(teacher, f"/submissions/{record['id']}/result")['analysis']
        records.append((record['id'], analysis['id']))
    with session() as db, db.begin():
        for _, identifier in records[:2]:
            analysis = db.get(AnalysisResult, identifier)
            analysis.configuration_snapshot = {**analysis.configuration_snapshot, 'algorithm_version': '2.0.0'}
    send(teacher, f"/reviews/{records[1][1]}/approve", {}, 201)
    with session() as db, db.begin():
        assert enqueue_unreviewed(db) == [records[0][0]]
    with session() as db, db.begin():
        assert enqueue_unreviewed(db) == []
        assert db.get(Submission, records[1][0]).status == SubmissionStatus.ANALYZED
        assert db.get(Submission, records[2][0]).status == SubmissionStatus.ANALYZED
    process()
    with session() as db, db.begin():
        assert enqueue_unreviewed(db) == []
        assert all(db.get(AnalysisResult, identifier) is not None for _, identifier in records)
        assert len(db.scalars(select(AnalysisResult)).all()) == 4
